#ifndef _STATISTICS_TEST_GROUP_H_
#define _STATISTICS_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(statistics_tests);

#endif /* _STATISTICS_TEST_GROUP_H_ */
